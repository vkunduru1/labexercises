
public class CheckingAccount extends Account{


	private int numberOfChequesUsed; /// stores the number of cheques used every month starting from zero.
	private double balance;
	
	public CheckingAccount(String id, double initialBalance) {
		super(id, initialBalance);
		numberOfChequesUsed = 0;
        this.balance = initialBalance;
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean withdraw(double amount) {
		   if (balance - amount - 1 >= 0) {
	            balance = balance - amount - 1;
	            return true;
	        } else {
	            return false;
	        }
	}

	@Override
	public void deposit(double amount) {
		balance = balance + amount - 1;
		// TODO Auto-generated method stub
		
	}
public void resetChequesUsed() {
	numberOfChequesUsed =  0; //number of cheques used, starting from 0.
}
	public int getChequesused() {
		return numberOfChequesUsed;
	}
	public boolean withdrawUsingCheque(double amount) {
		
		if (numberOfChequesUsed < 3 && balance - amount >= -10) { //transaction fee is free for first 3 cheques and balance drops to -10 the method doesn't affect the balance.
            balance = balance - amount;
            return true;
        
    } else if(balance - amount - 2 >= -10) {
            balance = balance - amount - 2;
            return true;
        } else {
		return false;
		
	}
	}
	 public static void main(String[] args) {
 		CheckingAccount bdot = new CheckingAccount("5",50000);
 		System.out.println(bdot.withdrawUsingCheque(60));
 		
 }
}


