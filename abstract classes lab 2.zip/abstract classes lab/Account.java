public abstract class Account {
	String id;
	double balance;
	//storing id and balance
	
	public Account(String id, double balance){
		this.id = id;
		this.balance = balance;
	}
	//initialise attributes 
	
	public String getId() {
		return id;
	}
	//getter
	public double getBalance() {
		return balance;
		
	}
	//getter
	public String toString() {
		return "Account [id=" + id + ", balance=" + balance + "]";
	}
	//string that contains id and balance
	
	public abstract boolean withdraw(double amount);
	//abstract method thats to be implemented buy subclasses.
	
	public abstract void deposit(double amount);
//abstract method thats to be implemented buy subclasses.
    
public static void main(String []args){
    
}
}

