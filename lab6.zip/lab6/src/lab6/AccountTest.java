package lab6;
//this program is used to run the java program and is set with values to print.
public class AccountTest {
	public static void main(String [] args) {
		Account balanse = new Account("shelina", 2345653, 50000000);
		balanse.toString();
	}
}
