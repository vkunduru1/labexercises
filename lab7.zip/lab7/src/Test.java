
public class Test {


    public static void main(String [ ] args)
    {

        //Person class test
    	Person johnny = new Person("billy", "05-02-1998");
        System.out.println(johnny.toString());
        System.out.println(johnny.age("05-02-1998"));


        //Student class test
        Student rob = new Student("paul","18-10-1993","545456518",new double[]{50,40,30,70,60});
        System.out.println(rob.toString());
        System.out.println(rob.getFinalMark());
        System.out.println(rob.getGrade());


        //UndergraduateStudent class test
        UndergraduateStudent kim = new UndergraduateStudent("jack","10-08-1997","9876789",new double[]{70,40,60,70,90},2017,"computer science");
        System.out.println(kim.toString());
        System.out.println(kim.getFinalMark());
        System.out.println(kim.getGrade());





    }

}
