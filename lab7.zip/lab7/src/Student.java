import java.util.Arrays;

public class Student extends Person{
	
	String studentId;
	double [] marks = new double[5];
	
	public Student(String name, String DoB, String studentId, double[] marks) {
		super(name,  DoB);
		this.studentId = studentId;
		this.marks = marks;
	}
	public double getFinalMark() {
		double Mark = 0;
		double average;
		for(int i = 0; i<marks.length; i++) {
			Mark += marks[i];
		
		} average = Mark/marks.length;
		return average;
	}
	public char getGrade(double Mark, char Grade) {
			
		  if (Mark >= 70) { 
		        Grade = 'A';
		        }else if (Mark >= 60 && Mark <70) { //if statement that asks if the mark is < a certain amount to assign a grade.
		            Grade = 'B'; //grade
		        } else if (Mark >= 50 && Mark < 60) {
		            Grade = 'C';
		        } else if (Mark >= 40 && Mark < 50) {
		            Grade = 'D';
		        } else if (Mark < 40) {
		            Grade = 'F';
		    }
		return Grade;
	}	
	
	public String toString() {
		return "Student [studentId=" + studentId + ", marks=" + Arrays.toString(marks) + ", name=" + name + ", DoB="
				+ DoB + ", getFinalMark()=" + getFinalMark()  +  "]";
	}
}
