import java.util.Calendar;

public class Person {
	static String name; //two instance variables
	int year = Calendar.getInstance().get(Calendar.YEAR); 
	String DoB; 
			

Person(String name, String DoB){ 
	
	 Person.name = name;
	 this.DoB = DoB; 
	
}
int age(String DoB) { 
	String[] storage = DoB.split("/"); 
	Calendar year = Calendar.getInstance(); 
	int thisYear = year.get(Calendar.YEAR);
	int birthYear = Integer.parseInt(storage[2]); 
	int age = thisYear - birthYear;  
	return age; 
}

String printIt(){ 
	return ("name = " + Person.name + " "+ "Age" + age(DoB) + " " + "Date of Birth " +" "+ DoB);


}

void printAll(){
	System.out.println(printIt()); 
}


}
