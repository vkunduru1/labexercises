import java.util.Arrays;

public class UndergraduateStudent extends Student{
	int year;
	String program;
	
	public UndergraduateStudent(String name, String DoB, String studentId, double[] marks, String program, int year) {
		super(name, DoB, studentId, marks);
		this.year = year;
		this.program = program;
		
// TODO Auto-generated constructor stub

	}
	
	double getFinalmark() {
		double total = 0;
		
		Arrays.sort(marks);
		
		for (int i = 0; i < marks.length; i++) {
			total += marks[i];
			
			total/=3;
			
			
		}
		return total;
		
		
}
	String getGrade() {
		if (this.getFinalmark() >= 40) {
			return "pass";
}
		else if (this.getFinalmark() < 40) {
			return "fail";
}
			return null;
}

	
	public String toString() {
		return "UndergraduateStudent [year=" + this.year + ", program=" + this.program + "]";
		
	}

}

