public class SavingsAccount extends Account{
		
	public SavingsAccount(String id, double initialDeposit) {
		super(id, initialDeposit);
	
			if(initialDeposit >= 1000.0) {
				balance += balance + 10;
			}//initial deposit is 10, if the deposit is greater than 1000 bank offers an extra 10 to account holder.
		}
	

	
	public boolean withdraw(double amount) {
		if(balance - amount - 3 >= 10) { //if statement that states that with every withdrawl the account is charged £3 and the balance always has to be greater than £10
			balance = balance - amount - 3; 
			return true;
		}else {
			return false;
		}
		// TODO Auto-generated method stub
		
	}

	
	public void deposit(double amount) {
		// TODO Auto-generated method stub
		balance = balance + amount; //adding money to account to increase balance
	}
	public double addInterest(double rate) {
		double interest = balance * rate /100;
		balance = balance + interest;
		return interest; //interest that grows monthly in account.
	}
	 public static void main(String[] args) {
	    	SavingsAccount volkan = new SavingsAccount("10",10000);
			System.out.println(volkan.addInterest(40));
			
	}
	
}

