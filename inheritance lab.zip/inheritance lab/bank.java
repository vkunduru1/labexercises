import java.util.ArrayList;

public class bank {
	
private final ArrayList<Account> accounts; //keeping record of accounts
private double savingsInterestRate;	//stores in percentage rate of interest in savings account.

public bank() {
    accounts = new ArrayList<Account>(); //initialise array list with new one.
}

public void setSavingsInterest(double rate) {
	this.savingsInterestRate = rate; //sets rate percentage
}
public int numberOfAccounts() { //returns the number of accounts active in the bank.
	return accounts.size(); 
}
public void addAccount(Account a) { //adds an account to the accounts ArrayList
    accounts.add(a);
}
public Account getAccount(String accountID) { //return the first Account object corresponding to given accountID and returns null If the specified account does not exist.
    for (Account account : accounts) {
        if (account.getId().equals(accountID)) {
            return account;
        }
    }
    return null;
}
public boolean deposit(String accountID, double amount) { // deposit provided amount into the account specified by accountID. If account is not found, then return false. Otherwise make the deposit and return true.
    Account account = getAccount(accountID);
    if (accountID != null) {
        account.deposit(amount);
        return true;
    } else {
        return false;
    }
}
public boolean withdraw(String accountID, double amount) { //withdraw provided amount from the account specified by accountID. Returns true if successful, false otherwise.
    Account account = getAccount(accountID);
    if (accountID != null) {
        return account.withdraw(amount);
    } else {
        return false;
    }
}
public boolean transfer(String fromAccountID, String toAccountID, double amount) { //withdraw from provided fromAccountID and deposit to specified toAccountID. if the transaction is successful it returns true and otherwise it returns true. The transaction fees corresponding to concrete implementations of withdraw and deposit will apply
    Account fromAccount = getAccount(fromAccountID);
    Account toAccount = getAccount(toAccountID);
    if (fromAccount != null && toAccount != null) {
        if (fromAccount.withdraw(amount)) {
            toAccount.deposit(amount);
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}
    public void addInterest() { // iterate through all accounts and add interest to the eligible accounts using the rate set in the class.
        for (Account account : accounts) {
            if (account instanceof SavingsAccount) {
                SavingsAccount savingAccount = (SavingsAccount) account;
                savingAccount.addInterest(savingsInterestRate);
            }
        }
    }
        public void reset() { // iterate through all accounts and reset the number of checks for applicable accounts.
            for (Account account : accounts) {
                if (account instanceof CheckingAccount) {
                    CheckingAccount checkingAccount = (CheckingAccount) account;
                    checkingAccount.resetChequesUsed();
                }
            }
        }
    

public static void main(String[] args) {
	CheckingAccount sufyaan = new CheckingAccount("100",7000);
	bank acc = new bank();
	acc.addAccount(sufyaan);
	
	System.out.println(acc.numberOfAccounts());
}
}
