import java.io.*;
import java.util.Scanner;

public class Reverse {
	public static void main(String [] args) throws IOException {
		
		Scanner word = new Scanner(System.in); //input file
		System.out.println("Enter file name: ");
		String fileName = word.nextLine();
		File file = new File(fileName);
		Scanner scanner = new Scanner(file);
		
		System.out.print("Output File Name: "); //output file
	    Scanner outputfileName = new Scanner(System.in);
		String outputfile = outputfileName.nextLine();
		FileWriter files = new FileWriter(outputfile);
		PrintWriter fileWriter = new PrintWriter(files);
		
		String[] storeWords = scanner.nextLine().split(" "); //empty array that splits the string from the file.
		
		for(int i = 0; i < storeWords.length; i++) { //for loop that goes through each string and moves it into the array
			System.out.println(storeWords[i]);
		}
		
	    	for (int i = storeWords.length-1; i >=0; i--) { //for loop that moves the elements from the array to the output file in reverse
	    		System.out.println(storeWords[i]);
	    		fileWriter.println(storeWords[i]);
	    			}
	    			word.close();
	    			scanner.close();
	    			outputfileName.close();
	    			files.close();
	    			fileWriter.close();	
	    }
	}
	

