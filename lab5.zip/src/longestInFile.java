import java.io.*;
import java.util.Scanner;

public class longestInFile
{
	public static void main(String [] args) throws IOException 
{

Scanner word = new Scanner(System.in); //user input
System.out.println("Enter file name: ");
String fileName = word.nextLine(); //checks how many lines in file
File file = new File(fileName);
Scanner scanner = new Scanner(file); 
String current; //current value
String next = ""; //next value

while (scanner.hasNext()) //while loop that runs while there is a string available then if the current word is greater than the next word it assigns that as the biggest word.
{
	current = scanner.next();

	if(current.length() > next.length()) {
			next = current;
			
}
}
System.out.println("Largest String = " + next);

}
}
