import java.util.*;
import java.io.*;
import java.util.Random;
public class Guessing {
	
	public static void main(String [] args) throws IOException {
		Scanner integers = new Scanner(System.in); 
		
		Random rand = new Random(); //random variable
		int randomNum = 0;
		int up = 1000;
		int down = 1;
		String guess;
		
			do {
			randomNum = (up + down +1) /2;  //equation to find random number
			System.out.println("i think the number is ... " + randomNum);
			guess = integers.nextLine();
			
			if (guess.equals("h")) { // high number
				down = randomNum + 1;
			}else if (guess.equals("l")) { // low number
				up = randomNum - 1;
			}}
			while (!guess.equals("c")); // while loop checks if number is correct enter "c"
				integers.close();
			
			
}
}