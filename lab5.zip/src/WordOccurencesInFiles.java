import java.io.*;
import java.util.Scanner;

public class WordOccurencesInFiles {
	private static Scanner word;
	private static Scanner mainFile;

	public static void main(String[] args) throws IOException {
	word = new Scanner(System.in); //user input
	System.out.println("Enter file name: "); 
	String fileName = word.nextLine(); //goes through every line in file
	File file = new File(fileName);
	mainFile = new Scanner(file);
	System.out.println("Which word do you want to print the occurences of?"); 
	String input = word.nextLine();

	int counter = 0; //counter is set to 0
	while(mainFile.hasNext()) { //while loop goes through the file and goes through each string in the file
		if(mainFile.next().equals(input))  //if statement that increments counter if the next word in the mainfile is equivalent to the previous value, if so the counter gets incremented by 1.
			counter++;
		}
	System.out.println(counter);
	/*
	 * LOOP through words in file
	 * 		IF file word == wordCheck
	 * 			counter++;
	 * 
	 */
}
}